const envOpts = {
  development: {
    startText: "running",
    buildCommand: ["start"],
  },
  production: {
    startText: "building",
    buildCommand: ["build"],
  },
};

module.exports = { envOpts };
