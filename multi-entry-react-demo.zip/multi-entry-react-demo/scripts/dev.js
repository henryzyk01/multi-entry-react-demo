// @ts-nocheck
const inquirer = require("inquirer");
const { inquirerPrompt, runParallel } = require("./common");

const question = inquirerPrompt();

/**
 * 交互
 */
inquirer.prompt([question]).then((res) => {
  runParallel(res.devLists);
});
