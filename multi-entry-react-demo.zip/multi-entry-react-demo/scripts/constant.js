// @ts-nocheck
const chalk = require("chalk");

const MAIN_FILE = "index.tsx";
const separator = "*";

const error = chalk.bold.red;
const warning = chalk.hex("#FFA500");
const success = chalk.green;

const maps = {
  success,
  warning,
  error,
};

/**
 * log
 * @param {string} message
 * @param {keyof maps} types
 */
const log = (message, types) => {
  console.log(maps[types](message));
};

/**
 * 不同环境publicPath
 */
const publicPathMap = {
  beta: "",
  prod: "",
};

module.exports = { MAIN_FILE, separator, log, publicPathMap };
