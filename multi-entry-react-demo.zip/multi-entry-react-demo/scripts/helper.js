// @ts-nocheck
const path = require("path");
const fs = require("fs");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const { MAIN_FILE, separator, publicPathMap } = require("./constant");

// 获取多页面入口文件夹中的路径
const dirPath = path.resolve(__dirname, "../src/pages/");

// 保存入口文件的Map对象
const entry = Object.create(null);

/**
 * 读取dirPath中的文件夹个数,同时保存到entry中  key为文件夹名称 value为文件夹路径
 */
fs.readdirSync(dirPath).filter((file) => {
  const entryPath = path.join(dirPath, file);
  if (fs.statSync(entryPath)) {
    entry[file] = path.join(entryPath, MAIN_FILE);
  }
});

/**
 * 根据入口文件list生成对应的htmlWebpackPlugin,同时返回对应wepback需要的入口和htmlWebpackPlugin
 * @param {*} pages
 * @returns entry htmlPlugins
 */
const getEntryTemplate = (pages, paths = null) => {
  const isEnvDevelopment = process.env.NODE_ENV === "development";
  const entry = Object.create(null);
  const htmlPlugins = [];
  const rewrites = [];
  pages.forEach((pagesName) => {
    entry[pagesName] = [
      require.resolve("react-error-overlay"),
      path.join(dirPath, pagesName, MAIN_FILE),
    ];

    htmlPlugins.push(
      new HtmlWebpackPlugin(
        Object.assign(
          {},
          {
            inject: true,
            template: paths.appHtml,
            filename: `${pagesName}/index.html`,
            chunks: [pagesName],
          },
          isEnvDevelopment
            ? {}
            : {
                minify: {
                  removeComments: true,
                  collapseWhitespace: true,
                  removeRedundantAttributes: true,
                  useShortDoctype: true,
                  removeEmptyAttributes: true,
                  removeStyleLinkTypeAttributes: true,
                  keepClosingSlash: true,
                  minifyJS: true,
                  minifyCSS: true,
                  minifyURLs: true,
                },
              }
        )
      )
    );
    rewrites.push({
      from: new RegExp(`^/${pagesName}.*`, "i"),
      to: `/${pagesName}/index.html`,
    });
  });

  return { entry, rewrites, htmlPlugins };
};

/**
 * 直接根据 process.env.packages 获取 entry htmlPlugins
 * @returns
 */
const getEntryHandle = (paths) => {
  const packages = process?.env?.packages?.split(separator);
  return getEntryTemplate(packages || [], paths);
};

const removePluginsByCondition = (plugins, condition) => {
  condition =
    !condition || typeof condition !== "function" ? () => false : condition;
  for (let i = 0; i < plugins.length; i++) {
    if (condition(plugins[i])) {
      plugins.splice(i, 1);
      i--;
    }
  }
  return plugins;
};
const appDirectory = fs.realpathSync(process.cwd());
const resolveApp = (relativePath) => path.resolve(appDirectory, relativePath);

function resolveModule(resolveFn, filePath, paths) {
  const extension = paths.moduleFileExtensions.find((extension) =>
    fs.existsSync(resolveFn(`${filePath}.${extension}`))
  );
  if (extension) {
    return resolveFn(`${filePath}.${extension}`);
  }
  // 默认js
  return resolveFn(`${filePath}.js`);
}

/**
 * webpack config
 * @param {*} webpackConfig
 * @param {*} params {env,paths}
 * @returns
 */
const configureWebpack = (webpackConfig, { env, paths }) => {
  const isDev = process.env.NODE_ENV === "development";
  const buildEnv = process.env.NODE_ENV === "production" ? "prod" : "beta";
  const { entry, htmlPlugins, rewrites } = getEntryHandle(paths);
  // entry
  console.log("env", webpackConfig.entry);
  // paths.appHtml = resolveApp("src/pages/demo/index.html");
  // paths.appIndexJs = resolveModule(resolveApp, "src/pages/demo/index", paths);
  // let entryVal = Object.values(entry);
  // webpackConfig.entry = entryVal.length > 1 ? { ...entry } : entryVal[0];
  webpackConfig.entry = { ...entry };
  //output
  webpackConfig.output.filename = isDev
    ? "js/[name].bundle.js"
    : "[name]/js/[name].[contenthash:8].js";
  webpackConfig.output.publicPath = isDev ? "/" : publicPathMap[buildEnv] || "";
  // plugins
  let plugins = removePluginsByCondition(
    webpackConfig.plugins,
    (item) =>
      item.constructor.name === "HtmlWebpackPlugin" ||
      item.constructor.name === "WebpackManifestPlugin" ||
      (!isDev && item.constructor.name === "MiniCssExtractPlugin")
  );
  // css
  const cssPlugin = isDev
    ? []
    : [
        new MiniCssExtractPlugin({
          filename: "[name]/css/[name].[contenthash:8].css",
          chunkFilename: "[name]/css/[name].[contenthash:8].chunk.css",
        }),
      ];

  webpackConfig.plugins = [...htmlPlugins, ...plugins, ...cssPlugin];

  console.log("env", env, webpackConfig.plugins, webpackConfig.entry, rewrites);
  return webpackConfig;
};

module.exports = { entry, getEntryTemplate, getEntryHandle, configureWebpack };
