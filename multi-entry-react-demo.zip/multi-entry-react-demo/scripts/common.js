// @ts-nocheck
const inquirer = require("inquirer");
const execa = require("execa");
const { log, separator } = require("./constant");
const { entry } = require("./helper");
const { envOpts } = require("./config");

const envOptions = envOpts[process.env.NODE_ENV];
inquirer.registerPrompt("search-checkbox", require("inquirer-search-checkbox"));

/**
 * inquirer.prompt 公共配置
 * @returns
 */
function inquirerPrompt() {
  const { pagesList, allPagesList } = initPagesList();
  return {
    type: "search-checkbox",
    message: "Please select the project to run:",
    name: "devLists",
    choices: allPagesList, // 选项
    prefix: "🏜",
    validate(value) {
      return !value.length
        ? new Error("Select at least one project to start")
        : true;
    },
    filter(value) {
      if (value.includes("all")) {
        return pagesList;
      }
      return value;
    },
  };
}

/**
 * 初始化页面列表
 * @returns
 */
function initPagesList() {
  // 获取pages下的所有文件
  const pagesList = [...Object.keys(entry)];

  // 至少一个
  if (!pagesList.length) {
    log("Invalid directory, please check src/pages/*/index.tsx", "warning");
    return;
  }

  const allPagesList = [...pagesList, "all"];
  return {
    pagesList,
    allPagesList,
  };
}

/**
 * 调用打包命令
 * @param {*} packages
 */
async function runParallel(packages) {
  const selectMsg = `Selected Page: ${packages.join(" , ")}`;
  const startMsg = `Start ${envOptions.startText} : ${packages.join("-")}`;

  log(selectMsg, "success");
  log(startMsg, "success");
  log("\nPlease waiting some times...", "success");

  await build(packages);
}

/**
 * build
 * @param {*} buildLists
 */
async function build(buildLists) {
  const stringLists = buildLists.join(separator);
  await execa("craco", envOptions.buildCommand, {
    stdio: "inherit",
    env: {
      packages: stringLists,
    },
  });
}

module.exports = { inquirerPrompt, runParallel };
