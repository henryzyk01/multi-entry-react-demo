// @ts-nocheck
const inquirer = require("inquirer");
const { inquirerPrompt, runParallel } = require("./common");

const initQues = inquirerPrompt();
const question = Object.assign(initQues, {
  message: "Please select the project to build:",
  name: "buildLists",
  prefix: "🚀",
});

inquirer.prompt([question]).then((res) => {
  runParallel(res.buildLists);
});
