import { Link, Outlet } from "react-router-dom";
import "./styles/index.scss";

const Views = () => {
  return (
    <div className="home">
      <p>Hello,This is a one View!</p>
      <Link to={"hh"}>to Home</Link>
      <Outlet />
    </div>
  );
};

export default Views;
