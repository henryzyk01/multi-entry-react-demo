import { createBrowserRouter } from "react-router-dom";
import Home from "@pages/one/app";
import Test from "@pages/one/view";
import HH from "./view/hh";

export const router = createBrowserRouter(
  [
    {
      path: "/",
      element: <Home />,
      // loader: rootLoader, // before mount
      children: [
        {
          path: "test",
          element: <Test />,
        },
      ],
    },
    {
      path: "/hh",
      element: <HH />,
    },
  ],
  { basename: "/one" }
);
