import { createBrowserRouter, Outlet } from "react-router-dom";
import Home from "@pages/demo/app";
import Test from "@pages/demo/view";

export const router = createBrowserRouter(
  [
    {
      path: "/",
      element: <Home />,
      // loader: rootLoader, // before mount
      children: [
        {
          index: true,
          path: "home",
          element: <Home />,
        },
        {
          path: "test",
          element: <Test />,
        },
      ],
    },
  ],
  { basename: "/demo" }
);
