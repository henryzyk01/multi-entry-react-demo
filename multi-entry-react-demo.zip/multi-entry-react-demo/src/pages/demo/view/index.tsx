const view = () => {
  return (
    <div>
      <p>Hello,This is a test view12312!</p>
    </div>
  );
};

export default view;
