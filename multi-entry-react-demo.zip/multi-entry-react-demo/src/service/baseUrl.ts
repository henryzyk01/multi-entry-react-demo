export const getUrl = (url: string) => {};
