import axios, { AxiosRequestConfig, AxiosResponse } from "axios";

const Axios = axios.create({
  timeout: 6000,
  withCredentials: true,
});

Axios.interceptors.request.use(
  (config: AxiosRequestConfig<any>) => {
    return config;
  },
  (err: any) => {
    console.log("interceptors.request", err);
    return Promise.reject(err);
  }
);

Axios.interceptors.response.use(
  (response: AxiosResponse<any, any>) => {
    // res
    // console.log('interceptors.response', response.data);
    const responseData = response.data;
    if (responseData.success === false) {
      const error = `请求失败：url= ${response.config.url}\nmethod：${
        response.config.method
      }\n参数：${
        response.config.method === "post"
          ? response.config.data
          : JSON.stringify(response.config.params)
      }\n返回：${JSON.stringify(responseData)}`;
      console.log(error);
      throw new Error(error);
    }
    if (responseData.success === undefined) {
      return Promise.resolve(responseData);
    }
    return Promise.resolve(
      responseData.data || responseData.obj || responseData.result
    );
  },
  (error: any) => {
    console.log("err-doRquest-interceptors", error);
    // res error // common toast process
    return Promise.reject(error);
  }
);

export default Axios;
