import Axios from "./index";
import { AxiosRequestConfig } from "axios";
import { baseOptionsParams, contentTypeKey, ReqHeaderOption } from "./types";
import { getUrl } from "./baseUrl";
const queryString = require("query-string");
const saasId = "duom";

/**
 * get request header
 * @param opts
 * @returns
 */
const getReqHeader = async (opts: ReqHeaderOption) => {
  const baseHeader = {
    Accept: "application/json;charset=utf-8",
    saas_id: saasId,
    JWT_TOKEN: "",
    Authorization: "",
  };
  const verificationType = {
    "SG-Verification-Type": opts.verificationType!,
    "SG-Verification-Sig": opts.sig!,
    "SG-Verification-Token": opts.token!,
    "SG-Verification-Scene": opts.scene!,
    "SG-Verification-Session-Id": opts.sessionId!,
  };
  const Authorization = {
    "SG-Verification-Type": opts.verificationType!,
    Authorization: opts.Authorization!,
    "SG-Verification-Session-Id": opts.sessionId!,
  };
  return Object.assign(
    baseHeader,
    opts.verificationType === 1
      ? verificationType
      : opts.Authorization
      ? Authorization
      : { MODE: opts.MODE ?? "" }
  );
};

const contentTypeOpt = {
  json: "application/json",
  encode: "application/x-www-form-urlencoded",
  form: "form-data",
};

const baseOptions: <T>(
  params: baseOptionsParams,
  method: string,
  opts?: any
) => Promise<T> = async (params, method = "GET", opts = undefined) => {
  const { url, data, contentType = "json" } = params;

  const BASE_URL = getUrl(url);
  const _contentType = contentTypeOpt[contentType];

  let requestData: { params?: Object; data?: Object } = {};

  if (method === "GET") {
    requestData = { params: { ...data } };
  } else if (method === "POST" || method === "DELETE") {
    const _data = Object.assign(data, {
      saas_id: saasId,
    });
    requestData = {
      data: contentType === "json" ? _data : queryString.stringify(_data),
    };
  }

  const option = {
    url: BASE_URL,
    method: method,
    headers: { "content-type": _contentType, ...(await getReqHeader(opts)) },
    ...requestData,
  };
  return Axios.request(option as AxiosRequestConfig<Object>);
};

const get: <T>(url: string, data?: Object, opts?: any) => Promise<T> = async (
  url,
  data,
  opts = {}
) => {
  const option = { url, data };
  return baseOptions(option, "GET", opts);
};

const post: <T>(
  url: string,
  data: Object,
  opts?: Object,
  contentType?: contentTypeKey
) => Promise<T> = async (url, data, opts = {}, contentType) => {
  const params = { url, data, contentType };
  return baseOptions(params, "POST", opts);
};

const _delete: <T>(url: string, data?: any) => Promise<T> = (url, data) => {
  const params = { url, data };
  return baseOptions(params, "DELETE");
};

export default {
  post,
  get,
  delete: _delete,
};
