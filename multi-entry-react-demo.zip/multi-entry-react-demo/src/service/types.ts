export interface ReqHeaderBaseOption {
  Accept?: string;
  saas_id?: string;
  deviceId?: string;
  traceId?: string;
  JWT_TOKEN?: string;
}
export interface OtherOptType {
  ignoreError?: boolean;
  verificationType?: string | number;
  sessionId?: string;
  Authorization?: string;
  needLogin?: boolean;
  isSilent?: boolean;
  jwtKey?: string;
  traffic?: string;
  scene?: string;
  token?: string;
  sig?: string;
  timeout?: number;
  rawBody?: boolean;
  params?: any;
  MODE?: string;
}

export type ReqHeaderOption = ReqHeaderBaseOption & OtherOptType;

export type contentTypeKey = "json" | "encode" | "form";
export interface baseOptionsParams {
  url: string;
  data?: any;
  contentType?: contentTypeKey;
}
