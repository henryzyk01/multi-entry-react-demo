import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface HomeState {
  value: number;
}

const initialState: HomeState = {
  value: 0,
};

export const counterSlice = createSlice({
  name: "home",
  initialState,
  reducers: {
    increment: (state) => {
      state.value += 1;
    },
  },
});

export const { increment } = counterSlice.actions;

export default counterSlice.reducer;
