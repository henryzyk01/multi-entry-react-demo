const path = require("path");
const { configureWebpack } = require("./scripts/helper");
const { getEntryHandle } = require("./scripts/helper");

module.exports = {
  webpack: {
    alias: {
      "@": path.resolve(__dirname, "src/"),
      "@pages": path.resolve(__dirname, "src/pages/"),
      "@store": path.resolve(__dirname, "src/store/"),
      "@utils": path.resolve(__dirname, "src/utils/"),
      "@service": path.resolve(__dirname, "src/service/"),
      "@components": path.resolve(__dirname, "src/components/"),
    },
    devServer: (devServerConfig, { env, paths, proxy, allowedHost }) => {
      const { rewrites } = getEntryHandle(paths);
      devServerConfig.historyApiFallback = {
        disableDotRule: true,
        rewrites: rewrites,
      };
      return devServerConfig;
    },
    configure: configureWebpack,
  },
};
