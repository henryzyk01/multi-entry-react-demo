# multi-entry-react-demo
multi entry archi in create-react-app 
